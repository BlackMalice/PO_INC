const express= require("express");
const app= express();
app.use(express.static('PO_INC'))
app.use('PO_INC/styles',express.static(__dirname +'PO_INC/styles'))
app.get('',(req,res)=>{
    res.sendFile(__dirname + '/inc_main.html')
})
app.listen(3000);
